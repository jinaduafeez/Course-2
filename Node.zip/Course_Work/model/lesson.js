const
    { MongoClient, ObjectId } = require('mongodb'),
    { client } = require('../dbConfig'),
    DATABASE = "course_work",
    COLLECTION = "lesson";


class Lesson {
    constructor(topic, price, location, space) {
        this.topic = topic;
        this.price = price;
        this.location = location;
        this.space = space;
        this.collection = client.db(DATABASE).collection(COLLECTION);

    }

    async createLesson() {
        const result = await this.collection.insertOne({
            topic: this.topic,
            price: this.price,
            location: this.location,
            space: this.space
        });
        return result;
    }

    async updateLesson(id, updatedLesson) {
        const result = await this.collection.updateOne(
            { _id: new ObjectId(id) },
            { $set: updatedLesson }
        );
        return result.modifiedCount > 0;
    }


    async updateLessonSpace(id, newSpace) {
        const result = await this.collection.updateOne(
            { _id: new ObjectId(id) },
            { $set: { space: newSpace } }
        );

        return result.modifiedCount > 0;

    }

    async getLessonById(id) {
        return this.collection.findOne({ _id: new ObjectId(id) });
    }

    async getAllLessons() {
        return this.collection.find().toArray();
    }

}

module.exports = Lesson;



