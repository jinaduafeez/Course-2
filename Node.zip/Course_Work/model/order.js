const
    { MongoClient, ObjectId } = require('mongodb'),
    { client } = require('../dbConfig'),
    DATABASE = "course_work",
    COLLECTION = "order";
class Order {
    constructor(name, phone, lessonIDs, numOfSpaces) {
        this.name = name;
        this.phone = phone;
        this.lessonIDs = lessonIDs instanceof Array ? lessonIDs : [lessonIDs];
        this.numOfSpaces = numOfSpaces;
        this.collection = client.db(DATABASE).collection(COLLECTION);
    }

    async createOrder() {
        const result = await this.collection.insertOne({
            name: this.name,
            phone: this.phone,
            lessonIDs: this.lessonIDs,
            numOfSpaces: this.numOfSpaces
        });
        return result;
    }

}

module.exports = Order;
