var express = require('express');
const { createLesson, getLessons, search, findbyid } = require('../controller/lessonController');
var router = express.Router();


router
    .route("/")
    .post(createLesson)
    .get(getLessons);

router.get("/search", search);


module.exports = router;