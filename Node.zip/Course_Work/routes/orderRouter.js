var express = require('express');
const { createOrder } = require('../controller/ordercontroller');
const { validateLessonExistence, findLessonAndUpdate } = require('../middleware/validate');
var router = express.Router();


router.use(validateLessonExistence);
router.use(findLessonAndUpdate)
router
    .route("/")
    .post(createOrder);


module.exports = router;