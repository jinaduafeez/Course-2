const Lesson = require("../model/lesson");


const validateLessonExistence = async (req, res, next) => {
    try {
        const lessonIDs = req.body.lessonIDs;
        const lessonModel = new Lesson();

        for (const lessonID of lessonIDs) {
            const lessonExists = await lessonModel.getLessonById(lessonID);
            if (!lessonExists) {
                return res.status(404).json({ error: `Lesson with ID ${lessonID} does not exist` });
            }
        }
        next();
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
};


const findLessonAndUpdate = async (req, res, next) => {
    const lessonIDs = req.body.lessonIDs;
    const lessonModel = new Lesson();
    for (const lessonID of lessonIDs) {
        const lessonExists = await lessonModel.getLessonById(lessonID);
        if (req.body.numberOfSpaces > lessonExists.space) {
            return res.status(404).json({ error: `Lesson with ID ${lessonID} does not have enough space` });

        } else {
            lessonModel.updateLessonSpace(lessonID, lessonExists.space - req.body.numberOfSpaces);
            next();

        }
    }
}

module.exports = {
    validateLessonExistence,
    findLessonAndUpdate
}