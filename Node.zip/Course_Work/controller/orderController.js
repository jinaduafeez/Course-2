const { validateLessonExistence, findLessonAndUpdate } = require("../middleware/validate");
const Order = require("../model/order");




const createOrder = async (req, res, next) => {
    try {
        const { name, phoneNumber, lessonIDs, numberOfSpaces } = req.body;
      //  await validateLessonExistence(req, res);
    //    await findLessonAndUpdate(req, res);

        const order = new Order(name, phoneNumber, lessonIDs, numberOfSpaces);
        const newOrder = await order.createOrder();

        res.status(201).json(newOrder);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
};

module.exports = {
    createOrder
}