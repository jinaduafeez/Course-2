const Lesson = require("../model/lesson");




const createLesson = async (req, res) => {
    try {
        const { topic, price, location, space } = req.body;

        const lessonModel = new Lesson(topic, price, location, space);

        const newLesson = await lessonModel.createLesson();

        res.status(201).json(newLesson);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}

const getLessons = async (req, res) => {
    try {
        const lessonModel = new Lesson();
        const allLessons = await lessonModel.getAllLessons();
        res.status(200).json(allLessons);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}


const search = async (req, res) => {
    try {
        const { query } = req.query;
        const lessonModel = new Lesson();
        if (!query) {
            return res.status(400).json({ error: 'Query parameter is required.' });
        }
        const searchResults = await lessonModel.searchLessons(query);
        res.status(200).json(searchResults);
    } catch (error) {
        console.error('Error searching lessons:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }

}



module.exports = {
    createLesson,
    getLessons,
    search
}