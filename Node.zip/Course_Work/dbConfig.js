


const { MongoClient, ServerApiVersion } = require('mongodb');
const uri = "mongodb+srv://afeezjinadu09:J3AKC8VjjtA7WTe0@cluster0.szq9gxh.mongodb.net/course_work?retryWrites=true&w=majority";

// Create a MongoClient with a MongoClientOptions object to set the Stable API version
const client = new MongoClient(uri, {
    serverApi: {
        version: ServerApiVersion.v1,
        strict: true,
        deprecationErrors: true,
    }
});




module.exports = { client }